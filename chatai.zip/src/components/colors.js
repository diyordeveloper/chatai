const LIGHT_THEME = {
  bgColor: "#FFFFFF",
  text: "#333333",
};

const DARK_THEME = {
  bgColor: "#343541",
  text: "#D9D9DE",
};

export { LIGHT_THEME, DARK_THEME };
